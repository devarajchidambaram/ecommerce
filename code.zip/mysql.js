module.exports = function initialize(mysql, moduleName) {

    var mysqlCreateConnection = mysql.createConnection;

    mysql.createConnection = function() {

        var result = mysqlCreateConnection.apply(this, arguments);

        var backQuery = result.query;

        result.query = function() {


            function traceFile() {
                try {
                    var err = new Error();

                    var previousFilePath, currentfilePath;

                    //https://github.com/v8/v8/wiki/Stack-Trace-API
                    Error.prepareStackTrace = function(err, stack) {
                        return stack;
                    };

                    var utilPath = "";

                    for (var i = 0; i < err.stack.length; i++) {
                        
                        if(err.stack[i].getFileName().includes('utility')){
                          utilPath = err.stack[i].getFileName();
                        }

                         if(utilPath != "") return utilPath.split('/')[utilPath.split('/').length - 1];

                    }

                } catch (err) {}
                return undefined;
            }

            var fileName = traceFile();  
            var start = new Date();
            var res = backQuery.apply(this, arguments);
            var end = new Date();
            var duration = end.getTime() - start.getTime();

            console.log("Request Date & Time===>", start, "FileName==>",fileName, " query==>", arguments[0].replace(/\?/g, arguments[1]), " Response Time===>", duration / 1000);

        }
  
      return result;
    }


}
