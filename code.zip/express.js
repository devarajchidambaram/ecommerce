module.exports = function initialize(express, moduleName) {
    
    // route(express);
    //var route = express.Route && express.Route.prototype;
    var Router = express.Router;

    var backReqAdd = Router.handle;

    Router.handle = function() {
    	
        var start = new Date();
        var result = backReqAdd.apply(this, arguments);

        var end = new Date();
        var duration = end.getTime() - start.getTime();

        console.log(arguments[0].url)

        if(arguments[0].url !== '/'){
        	console.log("Request Date & Time===>", start , " Request URL ==>" , arguments[0].headers.host + arguments[0].url , " Response Time===>" , duration/1000);
        }

        return result;
    }
}
